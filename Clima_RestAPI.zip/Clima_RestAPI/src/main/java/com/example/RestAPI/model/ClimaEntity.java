package com.example.RestAPI.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "clima")
public class ClimaEntity {

    @Id
    private String country;
    private String date;
    private String text;

    // Método construtor da classe
    public ClimaEntity(String country, String date, String text) {
        this.country = country;
        this.date = date;
        this.text = text;
    }

    // Getters e Setters
    public String getcountry() {
        return country;
    }

    public void setcountry(String country) {
        this.country = country;
    }

    public String getdate() {
        return date;
    }

    public void setdate(String date) {
        this.date = date;
    }

    public String gettext() {
        return text;
    }

    public void settext(String text) {
        this.text = text;
    }
}
