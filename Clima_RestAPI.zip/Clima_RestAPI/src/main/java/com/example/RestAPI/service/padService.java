package com.example.RestAPI.service;
import com.example.RestAPI.model.ClimaEntity;
import com.example.RestAPI.model.UserEntity;
import com.example.RestAPI.repository.ClimaRepository;
import com.example.RestAPI.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import org.json.JSONObject;
import org.json.JSONArray;

@Service
public class padService {

    String test = "";
    @Autowired
    private UserRepository userRepository;
    private ClimaRepository climaRepository;
    private ClimaEntity climaEntity;
    public String preverTempo() {
        String dadosMeteorologicos = "";
        //Nível BR
        String apiUrl = "https://apiadvisor.climatempo.com.br/api/v1/anl/synoptic/locale/BR?token=9fe25332679ebce952fdd9f7f9a83c3e";
        //Nível BH
        //String apiUrl = "http://apiadvisor.climatempo.com.br/api/v1/weather/locale/6879/current?token=9fe25332679ebce952fdd9f7f9a83c3e";

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.getForEntity(apiUrl, String.class);

        dadosMeteorologicos = responseEntity.getBody();

        String jsonStringWithoutBrackets = dadosMeteorologicos.substring(1, dadosMeteorologicos.length() - 1);

        try{
            JSONObject obj = new JSONObject(jsonStringWithoutBrackets);

            climaEntity.setdate(obj.getString("date"));
            climaEntity.setcountry(obj.getString("country"));
            climaEntity.settext(obj.getString("text"));

            inserir(climaEntity);

            return dadosMeteorologicos;



        }catch (Exception e){
            return "Deu ruim" +e;
        }

    }

    public List<UserEntity> obterTodos() {
        return userRepository.findAll();
    }

    public ClimaEntity inserir(ClimaEntity clima) {
        return climaRepository.save(clima);
    }
}
