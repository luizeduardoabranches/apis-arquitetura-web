package com.example.RestAPI.controller;

import com.example.RestAPI.model.UserEntity;
import com.example.RestAPI.service.padService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping()
public class Controller {

    //Classe de serviços
    @Autowired
    padService service = new padService();

    @GetMapping("/clima")
    public String preverTempo(){
        return service.preverTempo();
    }

    @GetMapping("/users")
    public List<UserEntity> obterTodos() {
        return service.obterTodos();
    }
}

